# jquery.fireworks
A fireworks animation plugin for jQuery

Adapted from http://jsfiddle.net/dtrooper/AceJJ/
See commits to [Supp](https://github.com/csudcy/supp) for some more history.
